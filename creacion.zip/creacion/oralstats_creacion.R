# Librerías ----

library(DBI)
library(RPostgreSQL)
library(tidyverse)
library(tidytext)
library(data.table)
library(phonfieldwork)
library(readr)
library(udpipe)
library(RSQLite)
library(stringr)
library(shiny)

# Establecer directorio de trabajo (Se necesita ejectura dentro de Rstudio)

setwd(dirname(rstudioapi::getSourceEditorContext()$path))

# Crear directorios

if (!dir.exists("eaf_sample")){
  dir.create("eaf_sample")
}else{
  print("ya existe")
}

if (!dir.exists("txt_sample")){
  dir.create("txt_sample")
}else{
  print("ya existe")
}

if (!dir.exists("textgrid_sample")){
  dir.create("textgrid_sample")
}else{
  print("ya existe")
}

if (!dir.exists("rsqlite")){
  dir.create("rsqlite")
}else{
  print("ya existe")
}

if (!dir.exists("revisiones")){
  dir.create("revisiones")
}else{
  print("ya existe")
}

if (!dir.exists("pitch")){
  dir.create("pitch")
}else{
  print("ya existe")
}

if (!dir.exists("intensity")){
  dir.create("intensity")
}else{
  print("ya existe")
}

if (!dir.exists("diccionarios")){
  dir.create("diccionarios")
}else{
  print("ya existe")
}

if (!dir.exists("udpipe")){
  dir.create("udpipe")
}else{
  print("ya existe")
}


if (!dir.exists("metadatos")){
  dir.create("metadatos")
}else{
  print("ya existe")
}

if (!dir.exists("outputs")){
  dir.create("outputs")
}else{
  print("ya existe")
}

if (!dir.exists("outputs/conversaciones")){
  dir.create("outputs/conversaciones")
}else{
  print("ya existe")
}

if (!dir.exists("outputs/rds")){
  dir.create("outputs/rds")
}else{
  print("ya existe")
}

if (!dir.exists("outputs/txts")){
  dir.create("outputs/txts")
}else{
  print("ya existe")
}
# Importar sources -----

## Localiza el directorio con los sources en tu ordenador. Inicialmente el script va a buscar los directorios en la misma carpeta en la que se encuentra el propio script.

## Principales----
### Opción 1 (RECOMENDADA). Texto exportado desde ELAN (archivo en formato TXT tabulado). -----

# Estructura (7 columnas separadas por tabulador; tiempo en milisegundos): tier spk time_start time_end duration content source

#a) Sin nombre de columnas (opción habitual)

pathtxt_no_columns <- "txt_sample/no_columns/sample_no_columnsname.txt"
if(file.exists(pathtxt_no_columns)){
  df <- read_delim(pathtxt_no_columns, 
                   delim = "\t", escape_double = FALSE, 
                   col_names = FALSE, trim_ws = TRUE) %>%rename(tier = X1, spk = X2, time_start = X3, time_end = X4, dur = X5, content = X6, source = X7)%>%mutate(source = gsub(".eaf","",source),spk =ifelse(is.na(spk),gsub("_.*","",tier),spk),spk = paste(source,spk,sep="_"))}else{NULL}

#a) Con nombre de columnas (los nombres deben ser: tier spk time_start time_end duration content source)

pathtxt_columns <- "txt_sample/columns/sample_columnsname.txt"
if(file.exists(pathtxt_columns)){
  df <- read_delim("txt_sample/sample_no_columnsname.txt", 
                   delim = "\t", escape_double = FALSE, 
                   col_names = FALSE, trim_ws = TRUE)}else{NULL}

### Opción 2. Archivos de ELAN (eaf) ------

elan <- list.files(pattern = "*.eaf",path = "eaf_sample",full.names = TRUE)

if(length(elan)){
df_eaf <-  elan %>% map_df(~eaf_to_df(.))
df <- df_eaf%>%filter(!is.na(content),!is.null(content),!is_empty(content),content!="")}else{NULL}

### Opción 3. Desde PRAAT (TextGrid)----
# Advertencia:

#a) Las comillas dentro de los contents de los textgrids deben ser simples. 
#b) Las etiquetas generan problemas en la importación.

textgrids <- list.files(pattern = "*.TextGrid",path = "textgrid_sample",full.names = TRUE)
if(length(textgrids)){df_tg <-  textgrids %>% map_df(~textgrid_to_df(file_name = .))
df_tg <- df_tg%>%filter(content!="")}else{NULL}

## Suplementarios ----

### Opción 4. Sources de pitch. Archivos pitchtier de PRAAT guardados con opción de headerless spreadsheet file. Para que funcione, deben manipularse para que solo haya dos columnas por archivo con nombre de columnas: time  pitch----

pitch <- list.files(pattern = "*.txt",path = "pitch",full.names = TRUE)
if(length(pitch)){df_pitch <-  pitch %>% map_df(~read_delim(.,delim = "\t",col_names = TRUE,id = "source"))%>%mutate(source = gsub("(.*/)(.*)(.txt)","\\2",source),time=round(time,2), pitch = round(pitch,2))}else{NULL}

### Opción 5. sources de intensidad. Archivos tableofreal procedentes de los intensitytiers de PRAAT, guardados con opción de headerless spreadsheet file. Para que funcione, deben manipularse para que solo haya dos columnas por archivo con nombre de columnas: time  intensity----

intensity <- list.files(pattern = "*.txt",path = "intensity",full.names = TRUE)
if(length(intensity)){df_int <-  intensity %>% map_df(~read_delim(.,delim = "\t",col_names = TRUE,id = "source"))%>%mutate(source = gsub("(.*/)(.*)(.txt)","\\2",source),time=(round(time,2)), intensity = round(intensity,2))}else{NULL}

### Opción 6. Diccionario fonético----

pathfonetico <- "diccionarios/fonetico.txt"

if (file.exists(pathfonetico)) {
fonetico <- read.delim(pathfonetico,header = FALSE,sep = "\t")%>%rename(ortografia = V1, ipatranscrip = V2)
lexicon <- fonetico %>%mutate(ipatranscrip = gsub(" ","",ipatranscrip))%>%rowwise() %>%mutate(vowels = gsub("[^aeiouˈ]","",ipatranscrip),t_pos = toString(which(strsplit(vowels, "")[[1]] == "ˈ")))%>%distinct(ortografia,.keep_all = TRUE)

}else {
  NULL
  }

### Opción 7. Sentimientos ----

pathsentimientos <- "diccionarios/sentimientos.txt"

if (file.exists(pathsentimientos)) {
  sentimientos <- read.delim(pathsentimientos,header = TRUE,sep = ",")
} else {
  NULL
}

### Opción 8. Metadatos de los hablantes----

# Los metadatos de los hablantes requieren un archivo que tenga un id_spk que coincida con el id_spk que se genera para el resto de transcripciones. La información que se añada aquí (sexo, nivel, edad, bilingüismo, etc.) dependerá de cada investigación y se arrastrará para el resto de unidades de más abajo (grupos entonativos, intervenciones, etc.)

pathmetadatos <- "metadatos/spkmetadatos.txt"

if (file.exists(pathmetadatos)) {
  spkmetadatos <- read.delim(pathmetadatos,header = TRUE,sep = "\t")
} else {
  NULL
}

# Prosodia----

if(exists("df_pitch")&exists("df_int")){
prosodia <- df_pitch %>%left_join(df_int, by=c("source","time"))}else{NULL}

# Sources ----

sources <- df %>%group_by(source)%>% summarise(grupos_entonativos=n())%>%mutate(ciudad=NA,genero=NA,pais=NA,tematica=NA,citacion=NA,autoria=NA,cualquiera=NA)%>%mutate(
  
  ciudad = ifelse(grepl("BAQ",source),"Barranquilla",ciudad),
  ciudad = ifelse(grepl("HAV",source),"La Habana",ciudad),
  ciudad = ifelse(grepl("LP",source),"Las Palmas",ciudad),
  ciudad = ifelse(grepl("MEX",source),"Ciudad de México",ciudad),
  ciudad = ifelse(grepl("VVU",source),"Santa Cruz",ciudad),
  ciudad = ifelse(grepl("IQ",source),"Iquique",ciudad),
  ciudad = ifelse(grepl("MTY",source),"Monterrey",ciudad),
  ciudad = ifelse(grepl("TCO",source),"Temuco",ciudad),
  ciudad = ifelse(grepl("TGU",source),"Tegucigalpa",ciudad),
  ciudad = ifelse(grepl("SC",source),"Santiago de Chile",ciudad),
  ciudad = ifelse(grepl("QRO",source),"Querétaro",ciudad),
  ciudad = ifelse(grepl("BUE",source),"Buenos Aires",ciudad),
  ciudad = ifelse(grepl("MDE",source),"Medellín",ciudad),
  ciudad = ifelse(grepl("PTY",source),"Ciudad de Panamá",ciudad),
  ciudad = ifelse(grepl("TUC",source),"Tucumán",ciudad)
  
  
)

# Unidades de habla ----

## Grupos entonativos básicos----

grupos <- df %>% filter(!grepl("word|phon|obs|Obs",tier))%>%mutate(id=paste(spk,time_start,sep="_"))

# Para conversaciones de Chiles

grupos <- grupos%>%mutate(spk1 = gsub("(.*)_\\(.*","\\1",spk))
grupos <- grupos%>%mutate(spk1 = gsub("(.*)\\(.*","\\1",spk1))
grupos <- grupos%>%mutate(spk1 = gsub(" ","_",spk1))
grupos <- grupos%>%mutate(spk1 = gsub("_$","",spk1),spk = spk1)%>%select(-spk1)

## Intervenciones ----

# Crear 

intervencionesdb <- grupos %>%arrange(source,time_start)
intervencionesdb$cambio <- ifelse(intervencionesdb$source == lead(intervencionesdb$source,1) & intervencionesdb$tier != lead(intervencionesdb$tier,1) ,
                           intervencionesdb$intid <- "cambio", 
                           ifelse(intervencionesdb$source != lead(intervencionesdb$source,1),
                                  intervencionesdb$intid <- "cambio",
                                  intervencionesdb$intid <- NA))
intervencionesdb <-  intervencionesdb %>% group_by(source,cambio) %>% mutate(intid = row_number())
intervencionesdb$intid <- ifelse(intervencionesdb$cambio != "cambio", intervencionesdb$intid <- NA, intervencionesdb$intid <- intervencionesdb$intid)

# Orden de las intervenciones

intervencionesdb <-  intervencionesdb %>% group_by(source) %>% 
  fill(intid, .direction = "up") #default direction down

# time_start de las intervenciones

intervencionesdb$time_start_int <- ifelse(lag(intervencionesdb$cambio == "cambio",1) | intervencionesdb$intid == 1, intervencionesdb$time_start_int <- intervencionesdb$time_start, intervencionesdb$time_start_int <- NA)
intervencionesdb <-  intervencionesdb %>% group_by(source) %>% 
  fill(time_start_int, .direction = "down") #default direction down

# time_end de las intervenciones

intervencionesdb$time_end_int <- ifelse(intervencionesdb$cambio == "cambio" | intervencionesdb$intid == 1, intervencionesdb$time_end_int <- intervencionesdb$time_end, intervencionesdb$time_end_int <- NA)
intervencionesdb <-  intervencionesdb %>% group_by(source) %>% 
  fill(time_end_int, .direction = "up") #default direction down

# Duración de las intervenciones

intervencionesdb$dur_int <- intervencionesdb$time_end_int - intervencionesdb$time_start_int

intervencionesdb <-  intervencionesdb %>% group_by(source,intid) %>% mutate(ordgeint = row_number())

#Creación de las pausas

intervencionesdb$pausa <- ifelse(intervencionesdb$source == lead(intervencionesdb$source,1) & intervencionesdb$tier == lead(intervencionesdb$tier,1), lead(intervencionesdb$time_start,1)-intervencionesdb$time_end,intervencionesdb$pausa <-NA)
intervencionesdb$pausacod <- ifelse(intervencionesdb$pausa<500, intervencionesdb$pausacod <- "/", 
                             ifelse(intervencionesdb$pausa>=501 & intervencionesdb$pausa <= 1000, intervencionesdb$pausacod <- "//", 
                                    ifelse(intervencionesdb$pausa>1001,intervencionesdb$pausacod <- paste("/// (", round((intervencionesdb$pausa*0.001),1),")",sep = ""),intervencionesdb$pausacod <-NA))) 
intervencionesdb$pausacod[is.na(intervencionesdb$pausacod)] <- " "

#Creación del valor de fto

intervencionesdb<- intervencionesdb%>%ungroup()%>%mutate(fto_post = ifelse((source == lead(source,1) 
                                                              & tier != lead(tier,1)), 
                                                             (lead(time_start,1)-time_end),NA),
                                           fto_post_cod = ifelse(fto_post>0 & fto_post<50,"§",NA),
                                           fto_pre = ifelse((source == lag(source,1) 
                                                             & tier != lag(tier,1)), 
                                                            (time_start-lag(time_end,1)),NA),
                                           fto_prev_cod = ifelse(fto_pre>0 & fto_pre<50,"§",NA))

intervencionesdb <- intervencionesdb%>%mutate(content1 = ifelse(!is.na(fto_post_cod)|!is.na(fto_prev_cod),paste(fto_prev_cod,content,pausacod,fto_post_cod, sep = ""), content),
                                content1 = gsub("^NA","",content1),
                                content1 = gsub("NA$","",content1),
                                content1 = ifelse(!is.na(pausacod),paste(content1,pausacod, sep = ""), content1),
                                content1 = gsub("NA$","",content1))


#Eliminación de los espacios iniciales

intervencionesdb$content1 <- trimws(intervencionesdb$content1)

#Creación de la variable "intervención" y de la base de datos "intervenciones"

intervencionesdb <- intervencionesdb %>% 
  group_by(source,intid) %>% 
  mutate(intervencion = paste0(content1, collapse = " "))
intervencionesdb$intervencion <- ifelse(intervencionesdb$cambio !="cambio", intervencionesdb$intervencion <- NA, intervencionesdb$intervencion <-intervencionesdb$intervencion)
intervencionesdb <- intervencionesdb %>% mutate(intervenciones_id = paste0(spk,"_int_",time_start_int, sep=""),grupo_id=id)
intervenciones <- subset(intervencionesdb, intervencionesdb$cambio == "cambio", select=c(tier,spk,source,time_end_int,time_start_int,intervencion))
intervenciones <- intervenciones %>% mutate(intervenciones_id = paste(spk,"_int_",time_start_int, sep=""))
intervenciones$intervencion_export <- paste(intervenciones$tier,": ",intervenciones$intervencion,sep = "")
intervenciones_export <- subset(intervenciones, select=c(time_start_int,intervencion_export,source))
intervenciones_export <- intervenciones_export %>% mutate(inicio = format(as.POSIXct(time_start_int / 1000, "UTC", origin = "1970-01-01"), "%H:%M:%OS2"))%>%select(inicio,intervencion_export,source)

## Palabras----

palabras <- df %>% filter(grepl("word|palabra",tier))%>%mutate(id=paste(spk,"pal",time_start,sep="_"))

### Sin tokenizado previo----

tokenized <- grupos%>%mutate(content = gsub("t=","t=&",content),content = gsub('">','">&',content),content = gsub('"/>','"/>&',content))%>%unnest_tokens(content,content,token = stringr::str_split, pattern = '&',to_lower = FALSE)%>%mutate(content=ifelse(grepl('"',content),gsub(" +","_",content),content),cita=NA,fsr=NA,fsr_attr=NA,extranjero=NA,extranjero_attr=NA,risas=NA,enfasis=NA,obs=NA)%>%unnest_tokens(content,content,token = stringr::str_split, pattern = ' ',to_lower = FALSE)%>%mutate(
  enfasis=ifelse(grepl("<enfasis",content),"yes",NA),enfasis=ifelse(grepl("</enfasis>",lag(content,1)),"no",enfasis))%>%fill(enfasis,.direction = "down")%>%mutate(enfasis=ifelse(is.na(enfasis),"no",enfasis))%>%mutate(
    risas=ifelse(grepl("<entre",content),"yes",NA),risas=ifelse(grepl("</entre",lag(content,1)),"no",risas))%>%fill(risas,.direction = "down")%>%mutate(risas=ifelse(is.na(risas),"no",risas))%>%mutate(
      cita=ifelse(grepl("<cita",content),"yes",NA),cita=ifelse(grepl("</cita>",lag(content,1)),"no",cita))%>%fill(cita,.direction = "down")%>%mutate(cita=ifelse(is.na(cita),"no",cita))%>%mutate(
        fsr=ifelse(grepl("<fsr",content),"yes",NA),fsr=ifelse(grepl("</fsr>",lag(content,1)),"no",fsr))%>%fill(fsr,.direction = "down")%>%mutate(fsr=ifelse(is.na(fsr),"no",fsr))%>%mutate(
          anonimo=ifelse(grepl("<anonimo",content),"yes",NA),anonimo=ifelse(grepl("</anonimo>",lag(content,1)),"no",anonimo))%>%fill(anonimo,.direction = "down")%>%mutate(anonimo=ifelse(is.na(anonimo),"no",anonimo))%>%mutate(
          extranjero=ifelse(grepl("<extranjero",content),"yes",NA),extranjero=ifelse(grepl("</extranjero>",lag(content,1)),"no",extranjero))%>%fill(extranjero,.direction = "down")%>%mutate(extranjero=ifelse(is.na(extranjero),"no",extranjero))%>%mutate(
  solap=ifelse(grepl("\\[",content),"yes",NA),solap=ifelse(grepl("\\]",lag(content,1))&!grepl("\\[",content),"no",solap))%>%fill(solap,.direction = "down")%>%mutate(solap=ifelse(is.na(solap),"no",solap))%>%mutate(
    interr=ifelse(grepl("\\¿",content),"yes",NA),interr=ifelse(grepl("\\?",lag(content,1))&!grepl("\\¿",content),"no",interr))%>%fill(interr,.direction = "down")%>%mutate(interr=ifelse(is.na(interr),"no",interr))%>% mutate(exclam=ifelse(grepl("\\¡",content),"yes",NA),exclam=ifelse(grepl("\\!",lag(content,1))&!grepl("\\¡",content),"no",exclam))%>%fill(exclam,.direction = "down")%>%mutate(exclam=ifelse(is.na(exclam),"no",exclam))%>%mutate(fsr_attr = ifelse(grepl("t=",lag(content,2))&grepl("fsr",lag(content,3)),lag(content,1),NA),extranjero_attr = ifelse(grepl("t=",lag(content,2))&grepl("extranjero",lag(content,3)),lag(content,1),NA),alargamiento=ifelse(grepl("<alargamiento",content),"yes","no"),content1 = gsub('\\¡|\\!|\\?|\\¿|".*"|\\[|\\]|-|–|\\(|\\)|<|\\/|>|entre_risas|fsr|obs|cita|extranjero|alargamiento|anonimo|t=|"|enfasis',"",content))%>%filter(content1!="")%>%group_by(id)%>%mutate(posicion_grupo = row_number())

#### Exportar para etiquetado Tagant o Freeling (inicialmente desactivado)----

# write_delim(tokenized%>%select(id,posicion_grupo,content1),"outputs/palabras_para_tag.txt")

#### Combinar etiquetados (freeling, tagant, udpipe)----

# Tagant es un programa creado por Laurecen Anthony y disponible en www.laurenceanthony.net

pathtagant <- "revisiones/tagant.txt"

if(file.exists(pathtagant)){
tagant <- read_delim(pathtagant, 
                     delim = "\t", escape_double = FALSE,  trim_ws = TRUE)%>%rename(content2=content1)}else{NULL}

# Freeling es un programa creado por Lluís Padró y disponible en https://nlp.lsi.upc.edu/freeling/node/1

pathfreeling <- "revisiones/freeling.txt"

if(file.exists(pathfreeling)){
freeling <- read_delim("revisiones/freeling.txt", 
                     delim = "\t", escape_double = FALSE,  trim_ws = TRUE)%>%rename(content3=content1)}else{NULL}


# Udpipe es una librería de R

pathudpipe <- "udpipe/spanish-ancora-ud-2.5-191206.udpipe"

if(file.exists(pathudpipe)){
spmodel <- udpipe_load_model("udpipe/spanish-ancora-ud-2.5-191206.udpipe")} else {spmodel<- udpipe_download_model(language = "spanish-ancora")
spmodel<-udpipe_load_model("spanish-ancora-ud-2.5-191206.udpipe")}

tokenized_udpipe <- udpipe_annotate(x=tokenized$content1,object = spmodel, tokenizer = "vertical",tagger = "default", doc_id=tokenized$id)%>%as.data.frame()
pathudpipe <- "revisiones/udpipe.txt"
if(exists(pathudpipe)){
  tokenized_udpipe <- read_delim("revisiones/udpipe.txt", 
                         delim = "\t", escape_double = FALSE,  trim_ws = TRUE)%>%rename(content3=content1)}else{NULL}

# En la siguiente línea se combinan los tres etiquetados. Aunque cualquier etiquetador puede ser válido, se recomienda UDPipe por su fácil integración en el entorno de R.

tokenized_tagged <- cbind(tokenized,tokenized_udpipe%>%rename(ulemma = lemma)%>%select(token,upos,ulemma)
                          # ,freeling%>%rename(freepos = pos,freelem = lemma)%>%select(content3,freepos,freelem),tagant
                          )%>%group_by(id)%>%mutate(palabras_id = paste(source,"_pal_",spk,"_",time_start,"_",row_number(),sep=""))

#### Añadir etiquetado sentimientos ----

if(exists("sentimientos")){
  
  tokenized_tagged_sent <- tokenized_tagged %>% left_join(sentimientos%>%distinct(palabra,.keep_all=TRUE), by=c("token"="palabra"))
  
}




### Revisión ----

# En este apartado se presupone que se ha descargado una versión tokenizada de la sección anterior, se ha revisado, por ejemplo, en un documento Excel y se vuelve a subir en este momento con las correcciones. Otra opción es realizar las correcciones con operación de sustitución directamente en R (mediante gsub).

# (quitar el comentario de más abajo solo si realmente es lo que se ha querido hacer)

# tokenized_tagged <- read_delim("revisiones/tokenized_tagged.txt", delim = "\t", escape_double = FALSE,  trim_ws = TRUE,col_names = TRUE)
## Ngramas----
###Ngrama1----
ngrama1 <- grupos%>%mutate(content = gsub("t=","t=&",content),content = gsub('">','">&',content),content = gsub('"/>','"/>&',content))%>%unnest_tokens(content,content)
###Ngrama2----
###Ngrama3----
###Ngrama4----



## Grupos entonativos avanzados----

#### Acústica----

prosodia_j <- setDT(prosodia%>%mutate(timems = time*1000))[setDT(grupos), on = .(source, timems >= time_start, timems < time_end), id := id]

# Definir cuartiles
prosodia_q <- prosodia_j%>%group_by(id)%>%mutate(dur=max(time)-min(time),
                                                 quartil = ifelse(time <= first(time)+(dur*0.25),"q1",NA),
                                                 quartil = ifelse(time <= first(time)+(dur*0.5)&time >= first(time)+(dur*0.25),"q2",quartil),
                                                 quartil = ifelse(time <= first(time)+(dur*0.75)&time >= first(time)+(dur*0.5),"q3",quartil),
                                                 quartil = ifelse(is.na(quartil),"q4",quartil))

# Aplicar resumen con los datos fónicos

prosodia_resumen <- prosodia_q%>%group_by(id)%>%summarise(pitch_mean=mean(pitch,na.rm = TRUE), intensity_mean= mean(intensity, na.rm = TRUE),inflexion_st = 12*log2(mean(pitch[quartil=="q4"],trim=0.1,na.rm=TRUE)/mean(pitch[quartil=="q1"],trim=0.1,na.rm=TRUE)),range_st = 12*log2(max(pitch,na.rm=TRUE)/min(pitch,na.rm=TRUE)))%>%mutate_if(is.numeric,round,digits=1)
prosodiaq4 <- prosodia_q%>%filter(quartil=="q4")%>%group_by(id)%>%summarise(pitch_mean=mean(pitch,na.rm=TRUE),trim=0.1)
prosodiaq1 <- prosodia_q%>%filter(quartil=="q1")%>%group_by(id)%>%summarise(pitch_mean=mean(pitch,na.rm=TRUE),trim=0.1)


grupos_ampliados <- grupos%>%left_join(prosodia_resumen, by="id")%>%rename(grupo_id = id)
grupos_ampliados <- grupos_ampliados%>%left_join(intervencionesdb%>%select(intervenciones_id,grupo_id),by="grupo_id")
grupos_pos <- tokenized_tagged%>%group_by(grupo_id = id)%>%summarise(
  
  qnoun = sum(upos=="NOUN",na.rm = TRUE),
  qverb = sum(upos=="VERB",na.rm = TRUE),
  qadj = sum(upos=="ADJ",na.rm = TRUE),
  qadv = sum(upos=="ADV",na.rm = TRUE),
  qadp = sum(upos=="ADP",na.rm = TRUE),
  qcconj = sum(upos=="CCONJ",na.rm = TRUE),
  qdet = sum(upos=="DET",na.rm = TRUE),
  qaux = sum(upos=="AUX",na.rm = TRUE),
  qintj = sum(upos=="INTJ",na.rm = TRUE),
  qnum = sum(upos=="NUM",na.rm = TRUE),
  qpron = sum(upos=="PRON",na.rm = TRUE),
  qpropn = sum(upos=="PROPN",na.rm = TRUE),
  qsconj = sum(upos=="SCONJ",na.rm = TRUE)
)%>%ungroup()
grupos_ampliados <- grupos_ampliados%>%left_join(grupos_pos, by="grupo_id")

grupos_sent <- tokenized_tagged_sent%>%group_by(grupo_id = id)%>%summarise(
  
  qpos = sum(sentimiento=="positivo",na.rm = TRUE),
  qneg = sum(sentimiento=="negativo",na.rm = TRUE)
  
)%>%ungroup()

grupos_ampliados <- grupos_ampliados %>%left_join(grupos_sent,by="grupo_id")


## Relaciones----

### Palabra por grupo entonativo----

cantidad_palabras_grupo <- tokenized_tagged%>%ungroup()%>%group_by(grupo_id=id)%>%summarise(palabras=n())

grupos_ampliados <- grupos_ampliados%>%left_join(cantidad_palabras_grupo,by="grupo_id")
grupos_ampliados <- grupos_ampliados%>%mutate(velocidad = palabras/(dur/1000))%>%mutate_if(is.numeric,round,digits=2)

### Fono, palabra, grupo entonativo from Alignment (solo si los datos han sido tokenizados y fonemizados en PRAAT o en otro programa)----

#### Revisar lexicon fonetico ----

if(length(lexicon)){
revisar_lexicon <- rbind(lexicon%>%mutate(source = "lexicon")%>%ungroup()%>%select(source,ortografia),tokenized_tagged%>%ungroup()%>%mutate(source = "revisar")%>%rename(ortografia=token)%>%select(source,ortografia))
revisar_lexicon<- revisar_lexicon%>%group_by(ortografia)%>%summarise(source=last(source),freq=n())%>%filter(freq==1, source=="revisar")
write_delim(revisar_lexicon%>%mutate(ipatranscrip=NA)%>%select(ortografia,ipatranscrip),"revisiones/revisar_lexicon.txt", delim ="\t")}else{NULL}

# Para utilizar la segmentación en palabras se recomienda que los grupos entonativos estén bien ajustados a los principios y finales de las palabras que los encuadran. La segmentación automática puede realizarse con PRAAT o con FASE (Wilbanks XXX). Para realizar las transformaciones de TOBI o AMH es necesario contar la sílaba tónica (anotada para ser procesada por Oralstats con un asterisco); esta anotación puede realizarse (semi)automáticamente con un diccionario fonético (se introduce uno en secciones anteriores)

fonos <- df%>%filter(grepl("phon|fon|fonemas|phonemes",tier))%>%mutate(time_start_phon = time_start, time_end_phon = time_end, id_fonos = paste(spk,"fono",time_start_phon,sep="_") )

palabras <- palabras%>%mutate(time_start_word = time_start, time_end_word = time_end )

palabras_j <- setDT(palabras)[setDT(grupos%>%select(id,source,spk,time_start,time_end,content)), on = .(source,spk, time_start_word >= time_start, time_end_word <= time_end)]%>%rename(content_grupo = i.content, grupo_id = i.id,time_start_grupo =time_start_word,time_end_grupo =time_end_word,time_start_word=time_start,time_end_word=time_end, id_palabras = id)

fonos_j <- setDT(fonos)[setDT(palabras_j%>%select(id_palabras,grupo_id,source,spk,time_start_word,time_end_word,content,content_grupo)), on = .(source,spk, time_start_phon >= time_start_word, time_end_phon <= time_end_word)]%>%rename(content_word = i.content,content_phon = content,time_start_word = time_start_phon,time_end_word = time_end_phon)%>%select(-time_start_word,-time_end_word)

fonos_j2 <- fonos_j%>%group_by(id_palabras)%>%mutate(order_phon_grupo = row_number())%>% group_by(id_palabras,type = grepl("[aeiou]",content_phon))%>%mutate(order_vowel_word = row_number())%>%ungroup()%>%mutate(type=ifelse(type=="TRUE","vowel","consonant"),type=ifelse(type=="consonant" &( content_phon=="j" |content_phon=="w"),"semivowel",type))%>%ungroup()%>%group_by(grupo_id,type)%>%mutate(order_vowel_grupo = row_number())%>%ungroup()

fonos_j2 <- fonos_j2%>%left_join(lexicon%>%select(t_pos,ortografia),by=c("content_word"="ortografia"))

fonos_j2 <- fonos_j2%>%mutate(tonica = ifelse(t_pos==order_vowel_word & type=="vowel","sí","no"))

tonemes<- fonos_j2%>%filter(tonica=="sí")%>%mutate(toneme=ifelse(lead(grupo_id)!=grupo_id,"sí","no"))
fonos_j2 <- fonos_j2%>%left_join(tonemes%>%select(id_fonos,toneme), by="id_fonos")

### Cálculo de la AMH ----

prosodia_fonos <- setDT(prosodia%>%mutate(timems = time*1000))[setDT(fonos_j2), on = .(source, timems >= time_start, timems < time_end), id := id_fonos]

prosodia_q_fonos <- prosodia_fonos%>%group_by(id)%>%mutate(dur=max(time)-min(time),
                                                 quartil = ifelse(time <= first(time)+(dur*0.25),"q1",NA),
                                                 quartil = ifelse(time <= first(time)+(dur*0.5)&time >= first(time)+(dur*0.25),"q2",quartil),
                                                 quartil = ifelse(time <= first(time)+(dur*0.75)&time >= first(time)+(dur*0.5),"q3",quartil),
                                                 quartil = ifelse(is.na(quartil),"q4",quartil))

q1alof <- prosodia_q_fonos%>%filter(quartil=="q1")%>%group_by(id)%>%summarise(q1piHz=mean(pitch,na.rm=TRUE))
q2alof <- prosodia_q_fonos%>%filter(quartil=="q2")%>%group_by(id)%>%summarise(q2piHz=mean(pitch,na.rm=TRUE))
q3alof <- prosodia_q_fonos%>%filter(quartil=="q3")%>%group_by(id)%>%summarise(q3piHz=mean(pitch,na.rm=TRUE))
q4alof <- prosodia_q_fonos%>%filter(quartil=="q4")%>%group_by(id)%>%summarise(q4piHz=mean(pitch,na.rm=TRUE))

prosodia_q_fonos <- prosodia_q_fonos%>% left_join(q1alof,by="id")
prosodia_q_fonos <- prosodia_q_fonos%>% left_join(q2alof,by="id")
prosodia_q_fonos <- prosodia_q_fonos%>% left_join(q3alof,by="id")
prosodia_q_fonos <- prosodia_q_fonos%>% left_join(q4alof,by="id")

prosodia_resumen_fonos <-
  suppressWarnings(prosodia_q_fonos%>%
                     group_by(id) %>% summarise(
                       source = max(source),
                       q1piHz = mean(q1piHz,na.rm=TRUE),
                       q2piHz = mean(q2piHz,na.rm=TRUE),
                       q3piHz = mean(q3piHz,na.rm=TRUE),
                       q4piHz = mean(q4piHz,na.rm=TRUE),
                       PirHz = max(pitch,na.rm = TRUE)-min(pitch,na.rm = TRUE),
                       Pimd = median(pitch, na.rm = TRUE),
                       PimnHz = mean(pitch, na.rm = TRUE),
                       Imn = mean(intensity, na.rm = TRUE),
                       corpus = "corpus"
                     )) %>%ungroup() %>%mutate_if(is.numeric,round, digits=2)

fonos_j3 <- fonos_j2%>%left_join(prosodia_resumen_fonos%>%select(-source), by=c("id_fonos"="id"))%>%mutate(excluir = ifelse(grepl("\\[",content_grupo),"sí","no"))%>%group_by(vowel = grepl("[aeiou]",content_phon))%>%mutate(primera_parte_lead = (lead(q1piHz,1)+lead(q2piHz,1))/2,desplazamiento = ifelse(lead(grupo_id,1)==grupo_id&((primera_parte_lead-q4piHz)/primera_parte_lead>0.09 | (((lead(q1piHz,1))-q4piHz)/lead(q1piHz,1))>0.09),"yes","no"))%>%ungroup()

anacrusis <- fonos_j3 %>%filter(tonica=="sí")%>%group_by(grupo_id)%>%mutate(orderanac = row_number())%>%filter(orderanac==1)%>%ungroup()%>%select(source,spk,id_fonos,grupo_id,content_phon,content_word,dur,PimnHz,q1piHz,q2piHz,q3piHz,q4piHz,desplazamiento)%>%rename_with(~ tolower(gsub("(.*)", "\\1_first", .x)))%>%rename(id_fonos=id_fonos_first,grupo_id=grupo_id_first)

cantidad_palabras <- fonos_j3%>%group_by(grupo_id)%>%summarise(words=n_distinct(id_palabras))
fonos_j3 <- fonos_j3%>%left_join(cantidad_palabras,by="grupo_id")
anacrusis_prev <- fonos_j3 %>%filter(tonica=="no", order_vowel_grupo==1, words>1,type=="vowel")%>%select(id_fonos,grupo_id,content_phon,content_word,dur,PimnHz,q1piHz,q2piHz,q3piHz,q4piHz,desplazamiento)%>%rename_with(~ tolower(gsub("(.*)", "\\1_preanac", .x)))%>%rename(id_fonos=id_fonos_preanac,grupo_id=grupo_id_preanac)

AMH <- fonos_j3%>%select(source,spk,time_start,time_end,id_fonos,grupo_id,content_phon,content_word,content_grupo,dur,PimnHz,q1piHz,q2piHz,q3piHz,q4piHz,toneme,desplazamiento)
AMH <- AMH%>%left_join(anacrusis,by="grupo_id")
AMH <- AMH%>%left_join(anacrusis_prev,by="grupo_id")
AMH <- AMH%>%mutate(body=(q1piHz-((q2pihz_first+q3pihz_first)/2))/((q2pihz_first+q3pihz_first)/2)*100, body =round(body,2), centroHz = (q3piHz+q2piHz)/2, circunflejo = ifelse(centroHz-q1piHz>0.09&q4piHz-centroHz< -0.09,"up_down","no"),circunflejo = ifelse(centroHz-q1piHz< -0.09&q4piHz-centroHz> 0.09,"down_up",circunflejo),tonemeMAS = round((q4piHz-q1piHz)/q1piHz*100,2),
                    MAStag = ifelse((((q1piHz - pimnhz_preanac)/pimnhz_preanac)*100 <40 | is.na(pimnhz_preanac)) & between(tonemeMAS,-40,15) &(desplazamiento_first=="no"|is.na(desplazamiento_first)),"PI",NA),
                    MAStag = ifelse((((q1piHz - pimnhz_preanac)/pimnhz_preanac)*100 <40 | is.na(pimnhz_preanac)) & tonemeMAS>70,"PII",MAStag),
                    MAStag = ifelse((((q1piHz - pimnhz_preanac)/pimnhz_preanac)*100 <40 | is.na(pimnhz_preanac)) & between(tonemeMAS,40,60)&desplazamiento_first=="yes","PIII",MAStag),
                    MAStag = ifelse((((q1piHz - pimnhz_preanac)/pimnhz_preanac)*100 <40 | is.na(pimnhz_preanac)) &desplazamiento_first=="yes" & circunflejo=="up_down","PIVa",MAStag),
                    MAStag = ifelse((((q1piHz - pimnhz_preanac)/pimnhz_preanac)*100 <40 | is.na(pimnhz_preanac)) &desplazamiento_first=="yes" & circunflejo=="up_down" & (between(body,-15,15)|is.na(body)),"PIVb",MAStag),
                    MAStag = ifelse((((q1piHz - pimnhz_preanac)/pimnhz_preanac)*100 <40 | is.na(pimnhz_preanac)) & between(tonemeMAS,-3,3) &(desplazamiento_first=="no"|is.na(desplazamiento_first)),"PV",MAStag),
                    MAStag = ifelse((((q1piHz - pimnhz_preanac)/pimnhz_preanac)*100 <40 | is.na(pimnhz_preanac)) & between(tonemeMAS,15,70)&(desplazamiento_first=="no"|is.na(desplazamiento_first)),"PVIa",MAStag),
                    MAStag = ifelse((((q1piHz - pimnhz_preanac)/pimnhz_preanac)*100 <40 | is.na(pimnhz_preanac)) & between(tonemeMAS,15,40)&desplazamiento_first=="yes","PVIb",MAStag),
                    MAStag = ifelse((((q1piHz - pimnhz_preanac)/pimnhz_preanac)*100 <40 | is.na(pimnhz_preanac)) & between(tonemeMAS,15,40)&desplazamiento_first=="yes"&between((q1piHz-q4pihz_first)/q4pihz_first*100,-10,10),"PVII",MAStag),
                    MAStag = ifelse(!grepl(" ",grupo_id) &  (desplazamiento_first=="no"|is.na(desplazamiento_first)),"PVIII",MAStag),
                    MAStag = ifelse((((q1piHz - pimnhz_preanac)/pimnhz_preanac)*100 <40 | is.na(pimnhz_preanac)) & tonemeMAS< -30 &(desplazamiento_first=="no"|is.na(desplazamiento_first)),"PIX",MAStag),
                    MAStag = ifelse((((q1piHz - pimnhz_preanac)/pimnhz_preanac)*100 <40 | is.na(pimnhz_preanac))  &desplazamiento_first=="yes" & circunflejo=="up_down","PXa",MAStag),
                    MAStag = ifelse((((q1piHz - pimnhz_preanac)/pimnhz_preanac)*100 <40 | is.na(pimnhz_preanac))  &desplazamiento_first=="yes" & circunflejo=="down_up","PXb",MAStag),
                    MAStag = ifelse((((q1piHz - pimnhz_preanac)/pimnhz_preanac)*100 <40 | is.na(pimnhz_preanac))  &desplazamiento_first=="yes" & tonemeMAS>60,"PXI",MAStag),
                    MAStag = ifelse((((q1piHz - pimnhz_preanac)/pimnhz_preanac)*100 <40 | is.na(pimnhz_preanac))&(between(body,-15,15)|is.na(body))  &desplazamiento_first=="yes" & tonemeMAS<0,"PXIIa",MAStag),
                    
                    MAStag= ifelse(toneme=="yes"&is.na(MAStag)&!is.na(tonemeMAS)&!is.na(PimnHz)&!is.na(q1piHz),"other",MAStag)
)

AMH_analysis <- AMH %>% filter(toneme=="sí")%>% select(grupo_id,source,spk,content_phon,content_word,content_grupo,time_start,time_end,dur,PimnHz,content_phon_first,content_word_first,dur_first,toneme,desplazamiento,content_phon_preanac,content_word_preanac,desplazamiento_preanac,dur_preanac,body,centroHz,circunflejo,tonemeMAS,MAStag)%>%mutate(tonemes = ifelse(MAStag=="PI","enunciativo",NA),tonemes = ifelse(MAStag%in%c("PII","PIII","PIVa","PIVb"),"interrogativo",tonemes),tonemes = ifelse(MAStag%in%c("PV","PVIa","PVIb"),"suspendido",tonemes), tonemes = ifelse(MAStag%in%c("PVII","PVIII","PVIX","PXa","PXb","PXI","PXIIa","PXIIB"),"enfático",tonemes)   
)

grupos_ampliados_AMH <- grupos_ampliados%>%left_join(AMH_analysis%>%select(grupo_id,content_phon_first,content_word_first,dur_first,desplazamiento,content_phon_preanac,content_word_preanac,desplazamiento_preanac,dur_preanac,body,centroHz,circunflejo,tonemeMAS,MAStag),by="grupo_id")

### Cálculo de tonemas TOBI ----

fonos_j4 <- fonos_j2%>% left_join(prosodia_resumen_fonos%>%select(-source), by=c("id_fonos"="id"))%>%mutate(excluir = ifelse(grepl("\\[",content_grupo),"sí","no"))%>%group_by(vowel = grepl("[aeiou]",content_phon))%>%mutate(primera_parte_lead = (lead(q1piHz,1)+lead(q2piHz,1))/2,ultima_parte_lag = (lag(q3piHz,1)+lag(q4piHz,1))/2,desplazamiento = ifelse(vowel==TRUE&lead(grupo_id,1)==grupo_id& 12*log2(primera_parte_lead/q4piHz)>1.5 | (12*log2(lead(q1piHz,1)/q4piHz)>1.5),"yes","no"),
              TOBI = ifelse(vowel==TRUE&12*log2(q4piHz/q1piHz)>1.5,"L+H*",NA),
              TOBI = ifelse(vowel==TRUE&12*log2(q4piHz/q1piHz)< -1.5,"H+L*",TOBI),  TOBI = ifelse(vowel==TRUE&12*log2(((q2piHz+q3piHz)/2)/q1piHz)>1.5 & 12*log2(q4piHz/((q2piHz+q3piHz)/2))< -1.5,"L+H*+L",TOBI),
              TOBI = ifelse(vowel==TRUE&12*log2(q4piHz/q1piHz)< -1.5,"H+L*",TOBI),  TOBI = ifelse(12*log2(((q2piHz+q3piHz)/2)/q1piHz)< -1.5 & 12*log2(q4piHz/((q2piHz+q3piHz)/2))> 1.5,"H+L*+H",TOBI),
              TOBI = ifelse(vowel==TRUE&is.na(TOBI)&desplazamiento=="yes","L*+H",TOBI),
              TOBI = ifelse(vowel==TRUE&is.na(TOBI)&12*log2(q1piHz/ultima_parte_lag)>1.5,"H*",TOBI),
              TOBI = ifelse(vowel==TRUE&is.na(TOBI)&12*log2(q1piHz/ultima_parte_lag)< -1.5,"L*",TOBI),
              TOBI = ifelse(vowel==TRUE&is.na(TOBI)&(!is.na(q1piHz)|!is.na(q4piHz)),"C",TOBI))%>%ungroup()%>%filter(!is.na(time_start))

grupos_ampliados_TOBI <- grupos_ampliados%>%left_join(fonos_j4%>%filter(toneme=="sí")%>%select(grupo_id,TOBI),by="grupo_id")

grupos_ampliados <- grupos_ampliados %>%left_join(grupos_ampliados_AMH%>%select(grupo_id,c(33:45)),by="grupo_id")%>%left_join(grupos_ampliados_TOBI%>%select(grupo_id,33),by="grupo_id")

# Hablantes----

speakers <- grupos_ampliados %>%group_by(spk)%>% summarise(grupos_entonativos_spk=n(),palabras_cantidad_spk=sum(palabras,na.rm = TRUE),palabras_mean_spk=mean(palabras,na.rm=TRUE),pitch_mean_spk = mean(pitch_mean,na.rm=TRUE),pitch_SD_spk = sd(pitch_mean,na.rm=TRUE),range_mean_spk = mean(range_st,na.rm=TRUE),range_SD_spk = sd(range_st,na.rm=TRUE),intensity_mean_spk=mean(intensity_mean,na.rm=TRUE),intensity_SD_spk=sd(intensity_mean,na.rm=TRUE),inflexion_mean_spk=mean(inflexion_st,na.rm=TRUE),inflexion_SD_spk=sd(inflexion_st,na.rm=TRUE),  dur_mean_spk = mean(dur, na.rm=TRUE),dur_SD_spk = sd(dur, na.rm=TRUE),velocidad_spk=mean(velocidad,na.rm=TRUE),velocidad_SD_spk=sd(velocidad,na.rm=TRUE))%>%mutate_if(is.numeric,round,digits=2)

cantidad_intervenciones <- intervenciones%>%group_by(spk)%>%summarise(intervenciones = n()) 

speakers <- speakers%>% left_join(cantidad_intervenciones,by="spk")%>%rename(grupos = grupos_entonativos_spk, palabras = palabras_cantidad_spk)

if(exists("spkmetadatos")){
speakers <- speakers %>%left_join(spkmetadatos%>%select(spk,source,sexo,edad,nivel), by="spk")%>%mutate(sexo=ifelse(is.na(sexo),"desconocido",sexo),edad=ifelse(is.na(edad),"desconocido",edad),nivel=ifelse(is.na(nivel),"desconocido",nivel))%>%distinct(spk,.keep_all = TRUE)}else {speakers <- speakers %>%mutate(sexo=NA,edad=NA,nivel=NA)}
## Grupos entonativos ampliados con diferencias respecto al hablante

grupos_ampliados2 <- grupos_ampliados %>% left_join(speakers,by="spk")%>%mutate(
 
  dif_pitch = 12*log2(pitch_mean/pitch_mean_spk),
  dif_range = range_st-range_mean_spk,
  dif_inten = intensity_mean-intensity_mean_spk,
  dif_inflexion = inflexion_st-inflexion_mean_spk,
  dif_dur = dur - dur_mean_spk,
  dif_velocidad = velocidad - velocidad_spk,
  dif_pitch_sign = (pitch_mean-pitch_mean_spk)/pitch_SD_spk,
  dif_range_sign = (range_st-range_mean_spk)/range_SD_spk,
  dif_inten_sign = (intensity_mean-intensity_mean_spk)/intensity_SD_spk,
  dif_inflexion_sign = (inflexion_st-inflexion_mean_spk)/inflexion_SD_spk,
  dif_dur_sign = (dur - dur_mean_spk)/dur_SD_spk,
  dif_velocidad_sign = (velocidad - velocidad_spk)/velocidad_SD_spk)%>%group_by(intervenciones_id)%>%mutate(
  posicion_en_intervencion = row_number())%>%ungroup() %>%mutate_if(is.numeric,round,digits=2)
grupos_ampliados2 <- grupos_ampliados2%>% select(-palabras_mean_spk,-inflexion_mean_spk,-pitch_mean_spk,-range_mean_spk, -intensity_mean_spk,-dur_mean_spk,-velocidad_spk)

### Añadir posiciones en grupo e intervención

tokenized_tagged <- tokenized_tagged %>% left_join(grupos_ampliados2%>%select(grupo_id,posicion_en_intervencion),by=c("id"="grupo_id"))
tokenized_tagged <- tokenized_tagged %>%ungroup()%>%arrange(source,time_start)%>% mutate(posicion_grupo_tag = ifelse(posicion_grupo==1&lead(posicion_grupo==2,1),"primera",NA),posicion_grupo_tag = ifelse(posicion_grupo!=1 & lead(posicion_grupo==1,1),"última",posicion_grupo_tag),posicion_grupo_tag = ifelse(posicion_grupo==1&lead(posicion_grupo==1,1),"única",posicion_grupo_tag),posicion_grupo_tag = ifelse(is.na(posicion_grupo_tag),"intermedia",posicion_grupo_tag))
tokenized_tagged <- tokenized_tagged%>%mutate(
  posicion_intervencion = ifelse(posicion_grupo_tag=="primera"&posicion_en_intervencion==1,"primera",NA),
  posicion_intervencion = ifelse(posicion_grupo_tag=="última"&lead(posicion_en_intervencion==1,1),"última",posicion_intervencion),
  posicion_intervencion = ifelse(posicion_grupo_tag=="única"&posicion_en_intervencion==1&lead(posicion_en_intervencion==1,1),"única",posicion_intervencion),
  posicion_intervencion = ifelse(is.na(posicion_intervencion),"intermedia",posicion_intervencion) )

# Almacenamiento de los datos ----

# Los datos pueden guardarse en diferentes formatos. La opción más conveniente es utilizar una base de datos, aunque también pueden almacenarse de otras formas: RDS, CSV, fst... En cuanto a las bases de datos, dos de las más extendidas son PostgreSQL y MySQL, aunque también puede usarse la opción de SQLite.

# En un entorno local, la base de datos RSQLite es más que suficiente, mientras que si la aplicación se aloja en un Shiny Server externo o en Shinyapps.io, es recomendable, de cara a la celeridad de la carga de los datos, que estos se alojen en un servidor externo con buena disponibilidad.



## Conexión con base de datos externa -----

### POSTGRESQL (inicialmente desactivado)----

# conexion <- dbConnect(RPostgreSQL::PostgreSQL(), host = "XXX",dbname="XXX", user = "XXX", password = "XXX")
# 
# ### Creación tablas e índices -----
# 
# dbWriteTable(conexion,"intervenciones",intervenciones,overwrite = TRUE)
# dbGetQuery(conexion,"CREATE UNIQUE INDEX index_intervencion
# on intervenciones (intervenciones_id);")
# dbWriteTable(conexion,"grupos",grupos_ampliados2%>%distinct(grupo_id,.keep_all = TRUE),overwrite = TRUE)
# dbGetQuery(conexion,"CREATE UNIQUE INDEX index_grupos
# on grupos (grupo_id);")
# dbGetQuery(conexion,"CREATE INDEX grupos_spk ON grupos(spk);")
# dbGetQuery(conexion,"CREATE INDEX grupos_source ON grupos(source);")
# dbWriteTable(conexion,"palabras",tokenized_tagged%>%distinct(palabras_id,.keep_all = TRUE)%>%select(-content,-content1),overwrite = TRUE)
# dbGetQuery(conexion,"CREATE UNIQUE INDEX index_palabras
# on palabras (palabras_id);")
# dbGetQuery(conexion,"CREATE INDEX index_forma ON palabras(token);")
# dbGetQuery(conexion,"CREATE INDEX index_lemma ON palabras(ulemma);")
# dbGetQuery(conexion,"CREATE INDEX index_upos ON palabras(upos);")
# dbWriteTable(conexion,"hablantes",speakers,overwrite = TRUE)
# dbGetQuery(conexion,"CREATE UNIQUE INDEX index_hablantes
# on hablantes(spk);")
# dbGetQuery(conexion,"CREATE INDEX index_spk_source ON hablantes(source);")
# dbGetQuery(conexion,"CREATE INDEX index_spk_sexo ON hablantes(sexo);")
# dbGetQuery(conexion,"CREATE INDEX index_spk_edad ON hablantes(edad);")
# dbGetQuery(conexion,"CREATE INDEX index_spk_nivel ON hablantes(nivel);")
# dbWriteTable(conexion,"conversaciones",sources,overwrite = TRUE)
# dbGetQuery(conexion,"CREATE UNIQUE INDEX index_sources
# on conversaciones (source);")
# dbGetQuery(conexion,"CREATE INDEX index_source_ciudad ON conversaciones(ciudad);")


## Conexión con base de datos local----

### RSQLITE ----

sqlitePath <- "rsqlite/database.sqlite"
connectsqlite <- dbConnect(RSQLite::SQLite(),sqlitePath)

### Crear tablas e índices ----

dbWriteTable(connectsqlite,"intervenciones",intervenciones, overwrite=TRUE)
dbGetQuery(connectsqlite,"CREATE UNIQUE INDEX index_intervencion
on intervenciones (intervenciones_id);")
dbWriteTable(connectsqlite,"grupos",grupos_ampliados2%>%distinct(grupo_id,.keep_all = TRUE)%>%select(-source.x,-source.y,-intervenciones,-sexo,-edad,-nivel),overwrite=TRUE)
dbGetQuery(connectsqlite,"CREATE UNIQUE INDEX index_grupos
on grupos (grupo_id);")
dbGetQuery(connectsqlite,"CREATE INDEX index_grupos_spk
on grupos (spk);")
dbGetQuery(connectsqlite,"CREATE INDEX index_grupos_conv
on grupos (source);")
dbWriteTable(connectsqlite,"palabras",tokenized_tagged%>%mutate(ulemma = toupper(ulemma))%>%distinct(palabras_id,.keep_all = TRUE)%>%select(-content,-content1),overwrite=TRUE)
dbGetQuery(connectsqlite,"CREATE UNIQUE INDEX index_palabras on palabras (palabras_id);")
dbWriteTable(connectsqlite,"hablantes",speakers,overwrite=TRUE)
dbGetQuery(connectsqlite,"CREATE INDEX index_hablantes on palabras (spk);")
dbWriteTable(connectsqlite,"conversaciones",sources,overwrite=TRUE)
dbGetQuery(connectsqlite,"CREATE UNIQUE INDEX index_conversaciones on conversaciones (source);")
# dbWriteTable(connectsqlite,"prosodia",prosodia_j)
# dbGetQuery(connectsqlite,"CREATE INDEX index_prosodia on prosodia (id);")
# dbGetQuery(connectsqlite,"CREATE INDEX index_source on prosodia (source);")
# dbGetQuery(connectsqlite,"CREATE INDEX index_time
# on prosodia (time);")

## Otros archivos ----

### Exportación a archivos de texto tabulado----

write_delim(speakers,"outputs/txts/speakers.txt",col_names = TRUE,delim = "\t")
write_delim(tokenized_tagged%>%mutate(ulemma = toupper(ulemma))%>%select(-content,-content1),"outputs/txts/tokenized_tagged.txt",col_names = TRUE,delim = "\t")
write_delim(grupos_ampliados2,"outputs/txts/grupos_ampliados2.txt",col_names = TRUE,delim = "\t")
write_delim(intervenciones,"outputs/txts/intervenciones.txt",col_names = TRUE,delim = "\t",)
write_delim(sources,"outputs/txts/sources.txt",col_names = TRUE,delim = "\t")
write_delim(prosodia_j,"outputs/txts/prosodia.txt",col_names = TRUE,delim = "\t")


### Crear transcripciones por intervenciones ----

intervenciones_export %>% group_by(source) %>% group_walk(~ write.table(.x, paste0("outputs/conversaciones/",.y$source, ".txt"), sep = "\t", row.names = TRUE, col.names = FALSE,quote=FALSE))

### Exportación a archivos RDS (formato nativo de R) ----

write_rds(speakers,"outputs/rds/speakers.RDS")
write_rds(tokenized_tagged%>%mutate(ulemma = toupper(ulemma))%>%select(-content,-content1),"outputs/rds/tokenized_tagged.RDS")
write_rds(grupos_ampliados2,"outputs/rds/grupos_ampliados2.RDS")
write_rds(intervenciones,"outputs/rds/intervenciones.RDS")
write_rds(sources,"outputs/rds/sources.RDS")
write_rds(prosodia_j,"outputs/rds/prosodia.RDS")

# Ejecución Shiny para explorar datos con Oralstats Aroca ----

runApp("oralstats_aroca.R")

# Ejecución Shiny para explorar datos con Oralstats ----

runApp("oralstats.R")
